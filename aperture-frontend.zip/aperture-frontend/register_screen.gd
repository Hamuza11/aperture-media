extends Control

# Replace with your actual live Cloudflare worker domain
const API_URL = "https://aperture-backend.hamza-h-kassem.workers.dev/register"
const UPLOAD_URL_TEMPLATE = "https://aperture-backend.hamza-h-kassem.workers.dev/upload/pfp_{user_id}.jpg"

@onready var username_input: LineEdit = $CenterContainer/RegistrationCard/ContentMargin/VBoxContainer/UsernameInput
@onready var password_input: LineEdit = $CenterContainer/RegistrationCard/ContentMargin/VBoxContainer/PasswordInput
@onready var register_button: Button = $CenterContainer/RegistrationCard/ContentMargin/VBoxContainer/RegisterButton
@onready var status_label: Label = $CenterContainer/RegistrationCard/ContentMargin/VBoxContainer/StatusLabel
@onready var register_request: HTTPRequest = $CenterContainer/RegistrationCard/ContentMargin/VBoxContainer/RegisterRequest
@onready var image_upload_request: HTTPRequest = $CenterContainer/RegistrationCard/ContentMargin/VBoxContainer/ImageUploadRequest
@onready var pfp_preview: TextureRect = $CenterContainer/RegistrationCard/ContentMargin/VBoxContainer/PfpSection/PfpPreview
@onready var select_pfp_button: Button = $CenterContainer/RegistrationCard/ContentMargin/VBoxContainer/PfpSection/ButtonAligner/SelectPfpButton

# Assuming you have a FileDialog node under the root scene node
@onready var file_dialog: FileDialog = $FileDialog

var selected_image_data: PackedByteArray
var user_id_to_upload: String = ""
var is_uploading_pfp: bool = false

func _ready() -> void:
	register_button.pressed.connect(_on_register_pressed)
	select_pfp_button.pressed.connect(_on_select_pfp_pressed)
	file_dialog.file_selected.connect(_on_pfp_file_selected)
	
	# Connect each request to its own dedicated callback
	register_request.request_completed.connect(_on_register_completed)
	image_upload_request.request_completed.connect(_on_upload_completed)

func _on_select_pfp_pressed() -> void:
	file_dialog.popup_centered_ratio(0.6)

func _on_pfp_file_selected(path: String) -> void:
	var img = Image.load_from_file(path)
	if img:
		var square_img = make_square_crop(img)
		pfp_preview.texture = ImageTexture.create_from_image(square_img)
		
		# Compress to a high-quality JPEG buffer
		selected_image_data = square_img.save_jpg_to_buffer(0.88)
		status_label.text = "Photo loaded successfully."

func make_square_crop(img: Image) -> Image:
	var width = img.get_width()
	var height = img.get_height()
	var size = min(width, height)
	
	var x = (width - size) / 2
	var y = (height - size) / 2
	
	# Crop out a 1:1 ratio from the center
	img.blit_rect(img, Rect2i(x, y, size, size), Vector2i.ZERO)
	img.crop(size, size)
	
	# Keep assets efficient for cellular uploads
	img.resize(256, 256, Image.INTERPOLATE_LANCZOS)
	return img

func _on_register_pressed() -> void:
	var username = username_input.text.strip_edges()
	var password = password_input.text

	if username.is_empty() or password.is_empty():
		status_label.text = "Please fill out all fields."
		return
	if selected_image_data.is_empty():
		status_label.text = "Please choose a photo first."
		return

	status_label.text = "Creating account..."
	register_button.disabled = true

	var headers = ["Content-Type: application/json"]
	var payload = { "username": username, "password": password }
	
	# Use the registration request node
	var error = register_request.request(API_URL, headers, HTTPClient.METHOD_POST, JSON.stringify(payload))
	if error != OK:
		status_label.text = "Network initialization failed."
		register_button.disabled = false

func _on_register_completed(result: int, response_code: int, headers: PackedStringArray, body: PackedByteArray) -> void:
	if response_code == 200:
		var json = JSON.new()
		if json.parse(body.get_string_from_utf8()) == OK:
			var data = json.get_data()
			user_id_to_upload = data.userId
			upload_pfp_to_storage()
		else:
			status_label.text = "Malformed server payload."
			register_button.disabled = false
	elif response_code == 409:
		status_label.text = "Username already taken."
		register_button.disabled = false
	else:
		status_label.text = "Server rejected registration."
		register_button.disabled = false

func upload_pfp_to_storage() -> void:
	status_label.text = "Uploading photo grid asset..."
	
	var upload_url = UPLOAD_URL_TEMPLATE.format({"user_id": user_id_to_upload})
	var headers = ["Content-Type: image/jpeg"]
	
	# Use the dedicated image upload request node
	var error = image_upload_request.request_raw(upload_url, headers, HTTPClient.METHOD_POST, selected_image_data)
	if error != OK:
		status_label.text = "Failed to open background binary upload stream."
		register_button.disabled = false

# Dedicated Phase 2 callback
func _on_upload_completed(result: int, response_code: int, headers: PackedStringArray, body: PackedByteArray) -> void:
	register_button.disabled = false
	
	# This prints vital low-level engine details to Godot's Output console
	print("--- UPLOAD DEBUG INFO ---")
	print("Engine Result Code: ", result) # e.g. 0 is success, 4 is connection error, etc.
	print("HTTP Response Code: ", response_code)
	print("Response Body Text: ", body.get_string_from_utf8())
	print("-------------------------")
	
	if response_code >= 200 and response_code < 300:
		status_label.text = "Success! Account & profile ready."
	else:
		status_label.text = "Photo sync failed. Code: " + str(response_code)
